/*Created a new form named calculate. 
    Has a function named calcAvgSquare that can calculate the average of 3 numbers times the square of the first number. The formula is: 
           ((num1 + num2 + num3)/3) * num12
    The function has 3 parameters.
    The function is called from the main program with 3 arguments. 
    The function returns the answer to the main program.
    Gets 3 numbers from the user in the main program (not in the function). 
    Function parameter names and the argument names (used in main program when calling the function) CANNOT be the same. 
    Outputs the answer from the main program (not from the function) using an alert with a template literal using this format: 
       The answer is XXX. 
    Code is all commented out. 
    Program runs without error.
*/
/*
function calcAvgSquare(num1, num2, num3){
  return (((parseInt(num1) + parseInt(num2) + parseInt(num3))/3) * (parseInt(num1)**2))
}

var number1 = prompt("Please enter the first number.")
var number2 = prompt("Please enter the second number.")
var number3 = prompt("Please enter the third number.")
calTotal= calcAvgSquare(number1, number2, number3)

alert(`The answer is ${calTotal}`)
*/