/*
myAnimals = ["dog", "cat", "horse", "meerkat"]
inptAnimals = prompt("Please input the name of the animal.")
lowerCaseAnimals = inptAnimals.toLowerCase()
myAnimals.push(lowerCaseAnimals)
outputAnimals = myAnimals[myAnimals.length -1]
alert(`The last animal is a/an ${outputAnimals}`)
*/

