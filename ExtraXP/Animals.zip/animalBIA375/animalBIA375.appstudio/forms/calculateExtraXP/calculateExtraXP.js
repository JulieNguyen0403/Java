/*Code from the calculate form has been copied and pasted into a new form named calculateExtraXP.
Removed all the 'let' commands from the copy (so you aren't re-creating the variables).
Asks the user if they want to do an average calculation or a random multiplication.
Gets a number from the user.
Uses a newly created function named randomMultiply that takes 1 parameter and multiplies a random number between 1 and 10 with the parameter number. Then returns the answer. 
Calls the appropriate function from the main program. 
Outputs the answer in an alert window with a template literal using this format: 

The result of multiplying the random number 9 with 100 is 900.

All user input and output is in main program, not in the function.
Code is all commented out. 
Program runs without error */
/*
optionChoice = prompt("Please enter average calculation or random multiplication")
  function calcAvgSquare(num1, num2, num3){
    return (((parseInt(num1) + parseInt(num2) + parseInt(num3))/3) * (parseInt(num1)**2))
  }
  
  function randomMultiply(amount){
    int rand = 0;
    while (true){
      rand = random.nextInt(100);
      if(rand !=0) break;
    }
  return amount * rand
  }
if (optionChoice == "average calculation"){
  number1 = prompt("Please enter the first number.")
  number2 = prompt("Please enter the second number.")
  number3 = prompt("Please enter the third number.")
  calTotal= calcAvgSquare(number1, number2, number3)
  alert(`The answer is ${calTotal}`)
} else {
  amountNum = prompt("Please enter the number.")
  multipleTotal = randomMultiply(amount)
  alert(`The result of multiplying the random number ${amountNum} is ${multipleTotal}`)
}
*/